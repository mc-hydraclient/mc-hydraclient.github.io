@echo off
chcp 65001 >nul
echo Installing HydraClient...
set "MODS=%APPDATA%\.minecraft\mods"
if not exist "%MODS%" mkdir "%MODS%"
copy /Y "%~dp0HydraClient-1.21.11.jar" "%MODS%\HydraClient-1.21.11.jar" >nul
if errorlevel 1 (
  echo ERROR: could not copy the file.
  pause
  exit /b 1
)
echo Done! HydraClient installed into:
echo %MODS%
echo Start Minecraft with the Fabric profile.
pause
