#!/bin/sh
echo "Installing HydraClient..."
MODS="$HOME/.minecraft/mods"
mkdir -p "$MODS"
cp "$(dirname "$0")/HydraClient-1.21.11.jar" "$MODS/HydraClient-1.21.11.jar"
echo "Done! HydraClient installed into: $MODS"
echo "Start Minecraft with the Fabric profile."
